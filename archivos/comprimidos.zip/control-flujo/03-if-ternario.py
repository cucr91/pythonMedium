edad = input("ingrese edad: ")
edad = int(edad)

# mensaje = "Es mayor" if edad > 17 else "Es menor"
# if edad > 17:
# mensaje = "es mayor"
# else:
# mensaje = "es menor"

# print(mensaje)

ingreso = "puede entrar " if edad >= 21 else "no puede entrar"
print(ingreso)
