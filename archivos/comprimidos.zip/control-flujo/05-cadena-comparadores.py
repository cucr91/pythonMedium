edad = 25

# if edad >= 15 and edad <= 65:
if 15 <= edad <= 65:
    print("Puede bañarse")
