# operadores logicos and, or, not

combustible = False
encendido = True
edad = 18

if not combustible and (encendido or edad > 17):
    print("Puedes conducir")
