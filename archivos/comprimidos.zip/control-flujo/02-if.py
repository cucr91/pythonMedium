edad = input("Ingrese su edad: ")
edad = int(edad)
if edad >= 50:
    print("Puede ver la pelicula con descuento")
elif edad >= 18:
    print("Eres mayor de edad, puedes ver la pelicula")
else:
    print("No puedes ver la pelicula")


print("Gracias por visitarnos")
