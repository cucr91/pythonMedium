# for numero in range(5):
#     print(numero)


buscar = 6
for numero in range(5):
    print(numero)
    if numero == buscar:
        print("encontrado", buscar)
        break
else:
    print("Numero no encontrado :(")


for char in "ultmate python":
    print(char)
