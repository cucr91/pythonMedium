nombre_curso = "Ultimate python"
descripcion_curso = """
ULTIMATE PYTHON
Este curso contempla todos los detalles que necesitas  aprender para encontrar un trabajo como programador
"""
# print(nombre_curso, descripcion_curso)
print(len(nombre_curso))
print(nombre_curso[0])
print(nombre_curso[0:8])
print(nombre_curso[9:])
print(nombre_curso[:8])
print(nombre_curso[:])
