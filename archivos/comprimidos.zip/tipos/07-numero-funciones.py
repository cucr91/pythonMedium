import math

print(round(1.3))  # roud devuelve el valor entero mas cercano, en este caso 1
print(round(1.7))   # roud devuelve el valor entero mas cercano, en este caso 2
print(round(1.5))
print(abs(-77))  # abs te entrega el valor absoluto, quita el signo.
print(abs(55))
print(abs(55.5))


print(math.ceil(1.1))  # ceil te lleva el numero a la base mayor
print(math.floor(1.999))  # floor te lleva el numero a la base menor
print(math.isnan(23))  # isnan indica si el argumento no es un numero
# print(math.isnan("veintitres"))
print(math.pow(10, 3))  # potencias
print(math.sqrt(9))  # raiz cuadrada
