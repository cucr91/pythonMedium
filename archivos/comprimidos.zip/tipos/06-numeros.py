numero = 2  # entero o interger
decimal = 10.5  # float
imaginario = 2 + 2j  # 2 + 2i

# numero = numero + 2

numero += 2
print("numero", numero)
numero *= 5
print("numero", numero)
numero -= 5
print("numero", numero)
numero /= 5
print("numero", numero)


# operaciones para realizar con numeros
print(1 + 3)  # suma
print(1 - 3)  # resta
print(1 * 3)  # multiplicaciom
print(1 / 3)  # division
print(1 // 3)  # division pero solo muestra enteros como resultado
print(8 % 3)  # Metodo
print(2 ** 3)  # potencia
