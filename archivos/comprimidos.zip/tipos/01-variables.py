nombre_curso= "Ultimate python"
nombre1= "Hola"
NombreCurso= "mundo"
NOMBRECURSO= "chanchito"
NoMBReCuRSo= "feliz"
print(nombre_curso, nombre1, NombreCurso, NOMBRECURSO, NoMBReCuRSo)

alumnos = 5000
puntaje = 9.9
publicado = True

print(alumnos, puntaje, publicado)