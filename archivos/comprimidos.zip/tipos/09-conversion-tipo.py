x = input("")

# int(): transforma datos a numeros (interger)
# str(): transforma datos a string
# float(): transforma datos a floar
# bool() transforma datos a boleanos;
# los falsos por defectos son 1- string vacios, 2- ceros, 3-none.

print(bool(""))  # Falso
print(bool("0"))  # True
print(bool(None))  # Falso
print(bool(" "))  # True
print(bool(0))  # Falso
