class Perro:
    def habla(self):
        print("guau!")


mi_perro = Perro()
mi_perro.habla()
print(isinstance(mi_perro, Perro))
