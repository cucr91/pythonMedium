mensaje = "hola Mundo"
print(type(mensaje))

# clase = Es el plano de construccion.
# objeto = Una instancia de una clase.

# En analagia con una casa
# clase = Es el plano de construccion de la casa
# objeto = Las casas construidas


# En analagia con una persona
# clase =  humano
# objeto = Nicolas, Felipe, Camilo, Valeska.
