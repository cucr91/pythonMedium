def hola(nombre, apellido="Feliz"):
    print("Bienvenido")
    print(f"Sr. {nombre} {apellido}")


hola("Camilo", "Calderón")
hola("chanchito")


hola(apellido="Calderón", nombre="Ulises")
