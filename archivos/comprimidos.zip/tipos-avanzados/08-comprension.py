usuarios = [["chanchito", 4],
            ["felipe", 1],
            ["pulga", 5]]

# nombre = []
# for usuario in usuarios:
#     nombre.append(usuario[0])
# print(nombre)

# transformacion (comprension de listas)
# nombres = [usuario[0] for usuario in usuarios]

# filtrar (comprension de listas)
# nombres = [usuario for usuario in usuarios if usuario[1] > 2]
# nombres = [usuario[0] for usuario in usuarios if usuario[1] > 2]

# MAP
# nombres = list(map(lambda usuario: usuario[0], usuarios))

# FILTER
# menosUsuarios = list(filter(lambda usuario: usuario[1] > 2, usuarios))

print(menosUsuarios)
