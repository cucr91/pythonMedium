mascotas = ["susi", "misifu", "duke", "chocolo", "aparecida"]

if "aparecida" in mascotas:
    print(mascotas.index("aparecida"))
