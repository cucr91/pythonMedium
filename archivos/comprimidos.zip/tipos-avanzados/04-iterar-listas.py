mascotas = ["susi", "misifu", "duke", "chocolo"]

for indice, mascota in enumerate(mascotas):
    print(indice, mascota)
