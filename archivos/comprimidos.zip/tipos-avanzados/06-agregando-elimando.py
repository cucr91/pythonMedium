mascotas = ["susi", "misifu", "duke", "chocolo", "aparecida", "lechona"]

mascotas.insert(1, "melvin")
mascotas.append("asesino")


mascotas.remove("aparecida")

mascotas.pop()
del mascotas[1]
mascotas.clear()
print(mascotas)

# agregar, eliminar y limpiar listas
