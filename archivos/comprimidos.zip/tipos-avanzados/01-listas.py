numeros = [1, 2, 3]
letras = ["a", "b", "c"]
palabras = ["chanchito", "feliz"]
palabrasFelices = ["feliz", "muyFeliz", "contento", "alegre"]
boleans = [True, False, False, True, True]
matriz = [[0, 1], [2, 3], [5, 6]]
ceros = [0, 1] * 10
alfaNumero = numeros + letras
rango = list(range(1, 11))
chars = list("hola mundo")
print(chars)


# print(numeros)
# print(letras)
# print(palabras)
# print(palabrasFelices)
# print(boleans)
# print(matriz)
# print(ceros)
# print(alfaNumero)
# print(rango)
