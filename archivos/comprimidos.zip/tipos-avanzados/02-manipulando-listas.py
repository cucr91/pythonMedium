mascotas = ["aparecida", "misifu", "chocolo", "duke"]
print(mascotas[0])
mascotas[0] = "susi"
# print(mascotas)
# print(mascotas[2:1])
# print(mascotas[-1])
# print(mascotas[::2])
# print(mascotas[1::2])

numeros = list(range(21))
print(numeros[::2])
print(numeros[1::2])
