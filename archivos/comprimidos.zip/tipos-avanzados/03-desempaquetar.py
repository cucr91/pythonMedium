numeros = list(range(1, 11))


# feo!
# primero = numeros[]
# segundo = numeros[1]
# tercero = numeros[2]

primero, segundo, *otros, decimo = numeros
print(primero, segundo, otros, decimo)
