def init(graphql):
    print("Soy modulo uno: {graphql}")
