def init(db, api, **otros):
    print(f"Soy modulo dos: {db} {api}")
