"""Introducción a python"""

print("Hola Mundo ! ")
print("El weta " * 3)

variable="Ultimate python"
print(variable)

